#ifndef PAYMENTINTERFACE_H_
#define PAYMENTINTERFACE_H_

class PaymentInterface
{

};

#endif /*RESERVATION_H_*/