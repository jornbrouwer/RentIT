#ifndef PASSENGERCAR_H_
#define PASSENGERCAR_H_

class PassengerCar: public Car
{

};

#endif /*PASSENGERCAR_H_*/