#include "Invoice.h"

Invoice::Invoice(const Reservation& aReservation)
:reservation(aReservation), fine(0)
{

}

Invoice::~Invoice(){}

void Invoice::getFine()
{
    std::string rendTime = reservation.getEndTime();
    std::string cendTime = reservation.getCar().getEndTime();
    if(cendTime > rendTime)
    {
        fine += reservation.getCustomer().getSubscription().getPrice();
        fine += reservation.getCar().getDrivenKm();
    }
}

eurocents Invoice::getTotalPrice()
{

}