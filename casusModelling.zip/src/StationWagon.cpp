#include "StationWagon.h"

StationWagon::StationWagon(unsigned long aDrivenKm, const std::string& anEndTime)
:Car(aDrivenKm, anEndTime)
{

}
StationWagon::~StationWagon(){}